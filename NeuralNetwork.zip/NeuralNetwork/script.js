let canvas = document.getElementById('script'); 
let ctx = canvas.getContext("2d");
var button = document.getElementById("Button");
var AnswerText = document.getElementById("Answer");
var text = document.getElementById("text");

canvas.width = 360;
canvas.height = 540;

let totalWidth = 540, totalHeight = 360,
    cellSize = 60, 
    numCellWidth = totalWidth / cellSize, 
    numCellHeight = totalHeight / cellSize,  
    grid = [[]],
    path = [],
    A = [[]],    
    B = [[]],
    C = [[]],
    solution = [[]],
    count = 0,
    color = 'white'; 

let drawing = false; // checks if mouse is clicked


class Grid {
    //constructor 
    constructor(posX, posY, width, height) {
        this.posX = posX;
        this.posY = posY;
        this.width = width;
        this.height = height;
        this.colored = false;
        this.value = 0;
        this.checked = false;
    }
    setValue(value)
    {
        this.value = value;
    }
    setChecked(bol)
    {
        this.checked = bol;
    }
    //draw method
    draw(ctx, color) {
        ctx.beginPath();
        ctx.rect(this.posX, this.posY, this.width, this.height);
        ctx.fillStyle = color;
        ctx.lineWidth = 2;
        ctx.strokeStyle = "black";
        ctx.fill();
        ctx.stroke();
    }
    //fill used to change the color of the rect
    fill(color) {
        this.colored = true;
        this.draw(ctx, color);
    }
}

function getMousePosition(canvas, e) {
    let rect = canvas.getBoundingClientRect();
    let pX = Math.floor(e.clientX - rect.left);
    let pY = Math.floor(e.clientY - rect.top);

    return { 
        //cursor location / cellsize to get position in grid
        y: Math.floor(pX / cellSize),
        x: Math.floor(pY / cellSize)
    };
}

function prepareGrid(){
    for (let i = 0; i < numCellWidth; ++i) {
        grid[i] = [];
        for (let j = 0; j < numCellHeight; ++j) 
            grid[i][j] = new Grid(j * cellSize, i * cellSize, cellSize, cellSize); 
    }
    for (let i = 0; i < numCellWidth; ++i)
        for (let j = 0; j < numCellHeight; ++j) 
            grid[i][j].draw(ctx, color);
}

canvas.addEventListener("mousedown", function(e){
        drawing = true;
})

canvas.addEventListener("mouseup", function(e){
        drawing = false;
})

canvas.addEventListener("mousemove", function(e){
    if(drawing){
        start = getMousePosition(canvas, e);
        if(!path.includes(grid[start.x][start.y]))
         path.push(grid[start.x][start.y]);
        grid[start.x][start.y].fill('black'); // Set color
        grid[start.x][start.y].checked = true;
    }
})
function setAllArrays()
{
    for (let i = 0; i < numCellWidth; ++i) {
        A[i] = [];
        B[i] = [];
        C[i] = [];
        solution[i] = [];
        for (let j = 0; j < numCellHeight; ++j) {
            A[i][j] = [];
            B[i][j] = [];
            C[i][j] = [];
            solution[i][j] = [];
            A[i][j] = 0;
            B[i][j] = 0;
            C[i][j] = 0;
            solution[i][j] = 0;
        }

    }
}

var keysDown = {};
addEventListener("keydown", function (e) { // to record user's input
  keysDown[e.keyCode] = true;
}, false);

addEventListener("keyup", function (e) { // to record user's input
  delete keysDown[e.keyCode];
}, false);



function fillArray()
{   
    if(count < 11){
    for (let i = 0; i < numCellWidth; ++i)
        for (let j = 0; j < numCellHeight; ++j) 
        {
            if(grid[i][j].checked)
            {
                grid[i][j].value += 1;
            }else
            { 
                grid[i][j].value -= 1;
            }
        }
        for (let i = 0; i < numCellWidth; ++i)
        for (let j = 0; j < numCellHeight; ++j) 
        {
            grid[i][j].fill('white');
            grid[i][j].checked = false;
        }
        count++;
        if(count == 3)
        {
            for (let i = 0; i < numCellWidth; ++i)
            for (let j = 0; j < numCellHeight; ++j) 
            {
                A[i][j] = grid[i][j].value;
                grid[i][j].value = 0;
            }
            text.innerHTML = "Training for B";
            
        }
        else if(count == 6)
        {
            for (let i = 0; i < numCellWidth; ++i)
            for (let j = 0; j < numCellHeight; ++j) 
            {
                B[i][j] = grid[i][j].value;
                grid[i][j].value = 0;
            }
            text.innerHTML = "Training for C";
        }
        else if(count == 9)
        {
            for (let i = 0; i < numCellWidth; ++i)
            for (let j = 0; j < numCellHeight; ++j) 
            {
                C[i][j] = grid[i][j].value;
                grid[i][j].value = 0;
            }
            button.innerHTML = "Guess Answer!";
            text.innerHTML = "Draw your Desired Letter";
        }
        else if(count >= 10)
        {
            for (let i = 0; i < numCellWidth; ++i)
            for (let j = 0; j < numCellHeight; ++j) 
            {
                solution[i][j] = grid[i][j].value;
                grid[i][j].value = 0;
            }
            findSolution();
            
        }
    }
}
function findSolution()
{
    var PosA = 0;
    var countA = 0;
    var PosB = 0;
    var countB = 0;
    var PosC = 0;
    var countC = 0;
    for (let i = 0; i < numCellWidth; ++i)
    for (let j = 0; j < numCellHeight; ++j) {
            PosA += A[i][j] * solution[i][j]; //multiply input by weight
            if (A[i][j] > 0) {
                countA += A[i][j];//get the sum of positive weights
            }
            PosB += B[i][j] * solution[i][j]; //multiply input by weight
            if (B[i][j] > 0) {
                countB += B[i][j];//get the sum of positive weights
            }
            PosC += C[i][j] * solution[i][j]; //multiply input by weight
            if (C[i][j] > 0) {
                countC += C[i][j];//get the sum of positive weights
            }
        }
    var pos = [];
    pos.push(PosA/countA);
    pos.push(PosB/countB);
    pos.push(PosC/countC);
    var max = 0;
    for( i = 1; i < pos.length; i++)
    {
        if(pos[i] > pos[max])
            max = i;
    }
    if(max == 0)
    var answer = 'A';  
    if(max == 1)
    var answer = 'B';  
    if(max == 2)
    var answer = 'C';  
    AnswerText.innerHTML = "The expected Answer is: " + answer;


}

setAllArrays();
prepareGrid();

const options = {
	method: 'GET',
	headers: {
		'X-RapidAPI-Key': 'd98bb94a3emsh4a67f798343b616p103acbjsnd4bff6210a5a',
		'X-RapidAPI-Host': 'currency-exchange.p.rapidapi.com'
	}
};
fetch('https://currency-exchange.p.rapidapi.com/exchange?from=USD&to=EUR&q=1.0', options)
	.then(response => response.json())
	.then(response => console.log(response))
	.catch(err => console.error(err));